#!/usr/bin/env python
# -*- coding: utf-8 -*
"""Script for backwards compatibility."""
from __future__ import unicode_literals

from medusa.__main__ import main

if __name__ == '__main__':
    main()
