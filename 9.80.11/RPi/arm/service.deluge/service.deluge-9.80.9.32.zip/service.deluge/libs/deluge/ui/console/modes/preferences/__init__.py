from __future__ import unicode_literals

from deluge.ui.console.modes.preferences.preferences import Preferences

__all__ = ['Preferences']
