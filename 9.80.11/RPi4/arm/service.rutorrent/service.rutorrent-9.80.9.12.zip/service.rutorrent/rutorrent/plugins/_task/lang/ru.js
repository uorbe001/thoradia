﻿/*
 * PLUGIN _TASK
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.tskCommand		= "Выполнение команды...";
 theUILang.tskCommandDone	= "Команда выполнена.";
 theUILang.tskConsole		= "Консоль";
 theUILang.tskErrors		= "Диагностика";
 theUILang.tskBackground	= "Спрятать";
 theUILang.tskStart		= "Старт";
 theUILang.tskFinish		= "Завершение";
 theUILang.tskElapsed		= "Затрачено";
 theUILang.tskPlugin		= "Плагин";
 theUILang.tskDeletePrompt	= "Вы действительно хотите удалить выбранные задачи?";
 theUILang.tskDelete		= "Удаление задач";
 theUILang.tskActivate		= "Активировать";
 theUILang.tskRemove		= "Удалить";
 theUILang.tskRefresh		= "Обновить";
 theUILang.tskRunning		= "Выполняется";
 theUILang.tskArg		= "Параметр";
 theUILang.tskTasks		= "Задачи";

thePlugins.get("_task").langLoaded();