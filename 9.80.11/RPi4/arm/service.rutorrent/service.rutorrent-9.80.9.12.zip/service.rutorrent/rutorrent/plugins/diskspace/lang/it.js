﻿/*
 * PLUGIN DISKSPACE
 *
 * Italian language file.
 *
 * Author: 
 */

 theUILang.diskNotification	= "Attenzione! Il disco è pieno. rTorrent potrebbe non funzionare correttamente, nessun dato verrà scaricato fino a che non liberi spazio su disco.";

thePlugins.get("diskspace").langLoaded();
