﻿/*
 * PLUGIN DATA
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.getData		= "Télécharger le fichier";
 theUILang.cantAccessData	= "Le serveur web n'a pas accès à ce fichier.";

thePlugins.get("data").langLoaded();