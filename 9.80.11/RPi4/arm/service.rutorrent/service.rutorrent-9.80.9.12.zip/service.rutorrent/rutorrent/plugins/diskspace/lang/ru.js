﻿/*
 * PLUGIN DISKSPACE
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.diskNotification	= "Внимание! Ваш диск переполнен. До тех пор, пока Вы не освободите дисковое пространство, данные загружаться не будут, и rTorrent может работать не корректно.";

thePlugins.get("diskspace").langLoaded();