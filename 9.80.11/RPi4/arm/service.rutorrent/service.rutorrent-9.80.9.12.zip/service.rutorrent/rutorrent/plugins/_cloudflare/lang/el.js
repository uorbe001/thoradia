﻿/* PLUGIN _CLOUDFLARE
 *
 * Greek language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCloudscraper		= "_cloudflare plugin: Το πρόσθετο cloudscraper δεν μπορεί να φορτωθεί στην Python";

thePlugins.get("_cloudflare").langLoaded();
