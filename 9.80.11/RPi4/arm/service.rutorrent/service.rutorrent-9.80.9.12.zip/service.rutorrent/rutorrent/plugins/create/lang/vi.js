﻿/*
 * PLUGIN CREATE
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.mnu_create			= "Tạo torrent...";
 theUILang.CreateNewTorrent		= "Tạo Torrent mới";
 theUILang.SelectSource			= "Chọn nguồn";
 theUILang.TorrentProperties		= "Các thuộc tính Torrent";
 theUILang.PieceSize			= "Kích thước mảnh";
 theUILang.Other			= "Khác";
 theUILang.StartSeeding			= "Chia sẻ ngay";
 theUILang.PrivateTorrent		= "Torrent riêng tư";
 theUILang.torrentCreate		= "Khởi tạo...";
 theUILang.BadTorrentData		= "Bạn phải điền đầy đủ các thông số!";
 theUILang.createExternalNotFound	= "Create plugin: Thành phần bổ sung sẽ không hoạt động. Máy chủ Web không thể truy cập các chương trình mở rộng.";
 theUILang.incorrectDirectory		= "Sai thư mục";
 theUILang.cantExecExternal		= "Không thể thực thi chương trình mở rộng";
 theUILang.createConsole		= "Bảng điều khiển";
 theUILang.createErrors			= "Lỗi";
 theUILang.torrentSave			= "Lưu";
 theUILang.torrentKill			= "Dừng";
 theUILang.torrentKilled		= "Quá trình tạo torrent đã ngừng lại.";
 theUILang.recentTrackers		= "Recent trackers";
 theUILang.source			= "Source";

thePlugins.get("create").langLoaded();