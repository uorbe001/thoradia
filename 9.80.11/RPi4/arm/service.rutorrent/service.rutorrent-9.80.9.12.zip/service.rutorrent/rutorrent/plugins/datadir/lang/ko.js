﻿/*
 * PLUGIN DATADIR
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.DataDir		= "저장 위치";
 theUILang.DataDirMove		= "데이터 파일 이동";
 theUILang.datadirDlgCaption	= "토렌트 데이터 디렉토리";
 theUILang.datadirDirNotFound	= "DataDir 플러그인: 올바르지 않은 디렉토리";
 theUILang.datadirSetDirFail	= "DataDir 플러그인: 작업 실패";

thePlugins.get("datadir").langLoaded();
