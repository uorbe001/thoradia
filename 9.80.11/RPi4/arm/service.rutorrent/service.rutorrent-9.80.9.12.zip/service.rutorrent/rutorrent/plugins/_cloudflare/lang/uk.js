﻿/* PLUGIN _CLOUDFLARE
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.cannotLoadCloudscraper		= "Плагін _cloudflare: Python не може завантажити модуль cloudscraper";

thePlugins.get("_cloudflare").langLoaded();
