﻿/*
 * PLUGIN CHECK_PORT
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.checkWebsiteNotFound = "Check_port plugin: Plugin will not work. Invalid configuration";
 theUILang.checkPort		= "Sprawdź stan portu";
 theUILang.portStatus		= [
 				  "Stan portu nieznany",
 				  "Port zamknięty",
 				  "Port otwarty"
 				  ];

thePlugins.get("check_port").langLoaded();