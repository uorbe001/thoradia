
uniConfig for SABnzbd 0.7.x
zoggy@sabnzbd.org

Changed by Safihre for 1.0.x

========================================================
LIBRARIES USED

jQuery
 * Project repository: https://github.com/jquery/jquery
 * Dual licensed under the MIT and GPL licenses:
 *    http://www.gnu.org/licenses/gpl.html
 *    http://www.opensource.org/licenses/mit-license.php

jQuery Form Plugin
 * Project repository: https://github.com/malsup/form
 * Dual licensed under the MIT and GPL licenses:
 *    http://www.gnu.org/licenses/gpl.html
 *    http://www.opensource.org/licenses/mit-license.php

Bootstrap v3.3.6 (http://getbootstrap.com)
 * Licensed under the MIT license
    Changed by Safihre, Nov 2015
    We include the icon-file directly into the CSS,
    this way we avoid errors when HTTPS is enabled
