
class DuplicateArgument(Exception):
    pass
